#include <stdio.h>

void main()
{
    int num=0;
    int num2=0;
    int num3=0;
    int num4=0;

    do
    {
        printf("Introduce un numero: ");
        scanf("%d", &num2);
        if(num2!=0)
        {
            num+=num2;
            num3;

        }
    }
    while(num2!=0);
    num4=num+num3;
    printf("El resultado de la suma es: %d",num4);
}


