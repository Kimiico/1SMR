#include <stdio.h>

void main()
{
   int Multiplos3=0;
   int Multiplos2=0;
   int Multiplos5=0;
   int num;
{
    while ()
        printf("Num%i: "i);
    scanf("%i ";&num);

    if (Multiplos2%2==0)
    {
       ContMultiplos2++;
    }
    else if(multiplos3%3==0)
    {
        ContMultiplos3++;
    }
    else if (multiplos5%5==0)
    {
        contMultiplos5++;
    }

}




}
