#include <stdio.h>

void main()
{
    int h1;
    int m1;
    int h2;
    int m2;

    printf("Introduzca la primera hora:" %d h1);
    scanf("%d" , &h1);

    printf("Ahora introduzca los minutos:" %d m1);
    scanf("%d" ; &m1);

    printf("Introduzca la primera hora:" %d h2);
    scanf("%d" , &h1);

    printf("Ahora introduzca los minutos:" %d m2);
    scanf("%d" ; &m1);

     if()
}
