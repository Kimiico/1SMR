#include <stdio.h>

void main()
{
    int base;
    int exponente;
    int resultado;

    printf("\nPon un numero entero: " );
    scanf("%d",&base);
    printf("\nPon el exponente de la base: ");
    scanf("%d",&exponente);
  {
      while (base*exponente)

      printf("base%d:" resultado);
      scanf("%d", &base);

    if (resultado==0)

    {
        Fin del programa;

    }

}

    printf("\nEl resultado es:  ,);


}
