#include <stdio.h>

void main()
{
    int a, b;
    printf ("\nIntroduzca dos numeros a y b: ");
    scanf ("%d%d", &a, &b);
    printf ("\n a vale: %i y b vale %i", a, b);
    printf ("\nLa suma de a y b vale: %d\n", a+b);
    printf ("\nLa resta de a y b vale: %d\n", a-b);
    printf ("\nEl producto de a y b vale: %d\n", a*b);
    printf ("\nEl cociente de a y b vale: %d\n", a/b);
}
