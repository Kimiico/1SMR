#include <stdio.h>

void main()
{
    printf("Mi primer programa en C");
}
