#include <stdio.h>

void main()
{
    char car;
    int i;
    float f;
    printf("Introduzca un caracter: ");
    scanf("%c", &car);
    printf("Introduzca un entero: ");
    scanf("%i", &i);
    printf("Introduzca un real: ");
    scanf("%f", &f);
    printf("El caracter es: %c\n", car);
    printf("El entero es: %i\n", i);
    printf("El real es: %f", f);
}

