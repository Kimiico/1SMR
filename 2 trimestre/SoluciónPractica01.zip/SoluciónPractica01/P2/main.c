#include <stdio.h>

void main ()
{
    int base,altura,area;
    printf ("\nCálculo del área de un rectángulo");
    printf ("\nPor favor, introduzca base y altura: ");
    /* Leer base y altura */
    scanf ("%i%i", &base, &altura);
    // Calcular e imprimir área
    area = base*altura;
    printf ("\n\nEl área del rectángulo es: %d\n", area);
}
