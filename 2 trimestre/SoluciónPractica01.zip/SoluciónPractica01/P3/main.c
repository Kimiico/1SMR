#include <stdio.h>

void main()
{
    int a,b,c;
    float r1,r2;

    printf("Introduce a: ");
    scanf("%i",&a);
    printf("Introduce b: ");
    scanf("%i",&b);
    printf("Introduce c: ");
    scanf("%i",&c);
    r1=((-1)*b+sqrt(b*b-4*a*c))/(2*a);
    r1=((-1)*b-sqrt(b*b-4*a*c))/(2*a);

    printf("r1: %f\nr2: %f",r1,r2);
}
