#include <stdio.h>

void main()
{
    int x = 10, y = 20,aux;
    printf("x vale %d e y vale %d\n", x, y);
    aux=x;
    x = y;
    y = aux;
    printf("Después del intercambio, x vale %d e y vale %d\n", x, y);
}
