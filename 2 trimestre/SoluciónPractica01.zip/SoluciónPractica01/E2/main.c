#include <stdio.h>

void main()
{
    int a, b, suma;
    printf ("\nIntroduzca dos numeros a y b: ");
    scanf ("%d%d", &a, &b);
    printf ("\n a vale: %i y b vale %i", a, b);
    suma = a+b;
    printf ("\nLa suma de a y b vale: %d\n", suma);
}
